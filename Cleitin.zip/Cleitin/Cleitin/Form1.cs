﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;

namespace Cleitin
{
    public partial class ClaitonAV : MetroForm
    {
        private readonly string _conexao = Cleitin.Properties.Settings.Default._conexao;

        public ClaitonAV()
        {
            InitializeComponent();
        }

     

        private void metroTile1_Click_1(object sender, EventArgs e)
        {
            //Abrir Arquivo via Explorer Dialogo
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Todos os Arquivos (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK) 
                {
                    string caminhoArquivo = ofd.FileName;
                    try
                    {
                        string hashSHA256 = CalcularhashSHA256(caminhoArquivo);
                        Clipboard.SetText(hashSHA256);
                        MetroMessageBox.Show(this,
                            $"Hash do arquivo \n{hashSHA256}",
                            "Hash Calculado",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    catch
                    {
                        MetroMessageBox.Show(this,
                            $"ERRO AO CALCULAR!",
                            "Hash Calculado",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                }
            }
        }

        private string CalcularhashSHA256(string caminhoArquivo)
        {
            //throw new NotImplementedException();
            //abrir o arquivoem modo leitura
            using(FileStream fs = File.OpenRead(caminhoArquivo))
            using(SHA256 sha256 = SHA256.Create())
            {
                //computa a hash do arquivo e converte em bytes
                byte[] hashBytes = sha256.ComputeHash(fs);
                //Retorna o valor como string
                return BitConverter.ToString(hashBytes)
                                   .Replace("-", "")
                                   .ToLower();
            }
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            using(OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Multiselect = true;
                ofd.Filter = "Todos os Arquivos (*.*)|*.*";
                if(ofd.ShowDialog() == DialogResult.OK)
                {
                    EscanearArquivo(ofd.FileNames);
                }
            }
        }

        private void EscanearArquivo(string[] fileNames)
        {
            foreach(string filename in fileNames)
            {
                string hash = CalcularhashSHA256(filename);
                bool infectado = EhVirus(hash);
                string titulo = infectado ? "Arquivos do MAUU" : "LIMPO";
                string mensagem = infectado ? $"o Arquivo" + $" \"{Path.GetFileName(filename)}\" Está Infectado" : $"O Arquivo \"{Path.GetFileName(filename)}\" Limpo";

                MessageBoxIcon icone = infectado ?
                    MessageBoxIcon.Warning : MessageBoxIcon.Error;
                MessageBoxButtons botoes = infectado ?
                    MessageBoxButtons.YesNo : MessageBoxButtons.OK;
                DialogResult resultado = MetroMessageBox.Show(
                    this,
                    mensagem,
                    titulo,
                    botoes,
                    icone);
                if (infectado && resultado == DialogResult.Yes)
                {
                    ExcluirArquivo(fileNames);
                }
                RegistrarLog(fileNames,hash,infectado ? "Infectado" : "Limpo");
            }
        }

        private bool EhVirus(string hash)
        {
            throw new NotImplementedException();
        }
    }
}


